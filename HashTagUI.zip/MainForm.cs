﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HashTagUI;

namespace HashTagUI
{
	public partial class MainForm : Form
	{
        public Account currentUser;
		public static Server server;
		public MainForm()
		{
			InitializeComponent();
		}

		private void btnLogin_Click(object sender, EventArgs e)
		{
            if (currentUser == null)
            {
                Form loginForm = new LoginForm(this);
                this.Hide();
                loginForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("로그아웃 성공");
                currentUser = null;
                btnLogin.Text = "log in";
                lblLoginText.Text = "로그아웃상태입니다";
                label2.Visible = true;
                label3.Visible = true;
                button1.Visible = false;
                button2.Visible = false;
                btnCheckTicket.Visible = true;
                btnBooking.Visible = true;
            }
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			server = new Server();
            makeServerAccount();
			Form loginForm = new LoginForm(this);
			loginForm.ShowDialog();
		}

		private void btnBooking_Click(object sender, EventArgs e)
		{
			Form searchForm = new BookingSearchForm(currentUser);
			searchForm.ShowDialog();
		}

		private void btnCheckTicket_Click(object sender, EventArgs e)
		{
            if (currentUser == null)
            {
                MessageBox.Show("로그인부터 하십시오!");
                return;
            }
            Form CheckTicket = new CheckTicketForm(currentUser);
			CheckTicket.ShowDialog();
		}
		public void makeServerAccount()
		{
			string line,id,pw,name,email;
            bool isAdmin;

			// Read the file and display it line by line.
            //@"C:\Users\jay\Documents\account.txt"
			
            //System.IO.StreamReader file = new System.IO.StreamReader(Server.prePath + "\\Data\\account.txt");
            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\정현오\Documents\Visual Studio 2010\전체 프로젝트\jdpAirplaneReservation\Data\account.txt");
            
			while ((line = file.ReadLine()) != null)
			{
                id = line.Substring(0, line.IndexOf(','));
                line = line.Substring(line.IndexOf(',') + 1);
                pw = line.Substring(0, line.IndexOf(','));
                line = line.Substring(line.IndexOf(',') + 1);
                name = line.Substring(0, line.IndexOf(','));
                line = line.Substring(line.IndexOf(',') + 1);
                email = line.Substring(0, line.IndexOf(','));
                line = line.Substring(line.IndexOf(',') + 1);
                isAdmin = bool.Parse(line);
                Account temp=new Account(id,pw,name,email,isAdmin);
                server.userInfo.Add(id,temp);
			}

			file.Close();
		}

        private void label3_MouseHover(object sender, EventArgs e)
        {

        }

        private void MainForm_Activated(object sender, EventArgs e)
        {
            if (currentUser == null)
            {
                label2.Visible = true;
                label3.Visible = true;
                button1.Visible = false;
                button2.Visible = false;
                btnBooking.Visible = true;
                btnCheckTicket.Visible = true;
            }
            else
            {
                label2.Visible =false;
                label3.Visible = false;
                if (currentUser.isAdmin)
                {
                    button1.Visible = true;
                    button2.Visible = true;
                    btnBooking.Visible = false;
                    btnCheckTicket.Visible = false;
                }
                else
                {
                    button1.Visible = false;
                    button2.Visible = false;
                    btnBooking.Visible = true;
                    btnCheckTicket.Visible = true;
                }
            }
        }
	}
}
