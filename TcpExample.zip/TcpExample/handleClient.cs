﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms;
using System.Net;
using MySql.Data.MySqlClient;

namespace TcpServerExample
{
    class handleClient
    {
        TcpClient clientSocket;
        int clientNo;
        internal static Dictionary<string, Account> dic_userInfo;
        internal static Dictionary<string, Airplane> dic_airplaneList;
        internal Dictionary<string, AlarmSeat> dic_alarmSeat = new Dictionary<string, AlarmSeat>();
        static handleClient()
        {
            dic_userInfo = new Dictionary<String, Account>();
            dic_airplaneList = new Dictionary<string, Airplane>();
        }
        public handleClient()
        {
            makeAccountInfo();
            addAirplaneList();
            addAlarmSeatList();
        }
        public void addAirplaneList()
        {
            //string id, region, country, depApt, destApt, date, time, cost, seats;
            try
            {
                String strConn = "Server=localhost;Database=airplane;Uid=root;Pwd=gusdh288&;";
                MySqlConnection conn = new MySqlConnection(strConn);
                conn.Open();
                String sql = "select * from airplane";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                MySqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    string id = rd.GetString(0); string region = rd.GetString(1); string country = rd.GetString(2);
                    string d_airport = rd.GetString(3); string a_airport = rd.GetString(4); string date = rd.GetString(5);
                    string time = rd.GetString(6); string cost = rd.GetString(7); string seat_info = rd.GetString(8);

                    Airplane temp = new Airplane(id, region, country, d_airport, a_airport, date, time, int.Parse(cost), seat_info);
                    if (dic_airplaneList.ContainsKey(id))
                        continue;
                    dic_airplaneList.Add(id, temp);
                }

                rd.Close();
                conn.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        public void addAlarmSeatList()
        {
            //string id, region, country, depApt, destApt, date, time, cost, seats;
            try
            {
                String strConn = "Server=localhost;Database=airplane;Uid=root;Pwd=gusdh288&;";
                MySqlConnection conn = new MySqlConnection(strConn);
                conn.Open();
                String sql = "select * from alarmseat";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                MySqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    string id = rd.GetString(0); string airplane_id = rd.GetString(1); string seat = rd.GetString(2); string check = rd.GetString(3);

                    AlarmSeat temp = new AlarmSeat(id, airplane_id, seat, check);
                    dic_alarmSeat.Add(id, temp);
                }

                rd.Close();
                conn.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        public void startClient(TcpClient ClientSocket, int clientNo)
        {
            this.clientSocket = ClientSocket;
            this.clientNo = clientNo;

            Thread t_hanlder = new Thread(doChat);
            t_hanlder.IsBackground = true;
            t_hanlder.Start();
        }

        public void makeAccountInfo()
        {
            try
            {
                string id="", pw="", name="", email="", airplane_id="", seat_info="", interest="";
                String strConn = "Server=localhost;Database=airplane;Uid=root;Pwd=gusdh288&;";
                MySqlConnection conn = new MySqlConnection(strConn);
                conn.Open();
                String sql = "select * from account";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                MySqlDataReader rd = cmd.ExecuteReader();

                
                while (rd.Read())
                {
                    id = rd.GetString(0); pw = rd.GetString(1); name = rd.GetString(2); email = rd.GetString(3); interest = rd.GetString(6); airplane_id = rd.GetString(4); seat_info = rd.GetString(5);
                    Account newUser = new Account(id, pw, name, email, interest, airplane_id, seat_info);
                    dic_userInfo.Add(id, newUser);
                    MessageBox.Show(id + pw + name + email);
                }

                rd.Close();
                conn.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

        }

        public delegate void MessageDisplayHandler(string text);
        public event MessageDisplayHandler OnReceived;

        public delegate void CalculateClientCounter();
        public event CalculateClientCounter OnCalculated;

        private void doChat()
        {
            NetworkStream stream = null;
            try
            {
                byte[] buffer = new byte[1024];
                string msg = string.Empty;
                int bytes = 0;
                int MessageCount = 0;

                while (true)
                {
                    MessageCount++;
                    stream = clientSocket.GetStream();
                    bytes = stream.Read(buffer, 0, buffer.Length);
                    msg = Encoding.Unicode.GetString(buffer, 0, bytes);
                    msg = msg.Substring(0, msg.IndexOf("!"));
                    if (msg.Equals("LOAD"))
                    {
                        msg=sendAirplaneList();
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("RES"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string airplane_id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string seat = msg;
                        msg = reserve(id, airplane_id, seat);
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("NACC"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string pw = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string name = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string email = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string interest = msg;
                        msg = addAccount(id, pw, name, email, interest);
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("CANS"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string airplane_id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string seat = msg;
                        msg = cancel(id, airplane_id, seat);
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("MODA"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string pw = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string name = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string email = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string interest = msg;
                        msg = modifyAccount(id, pw, name, email, interest);
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("LOGIN"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string pw = msg;
                        msg = login(id, pw);
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("FINDID"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string name = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string email = msg;
                        msg = findid(name, email);
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("FINDPW"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string name = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string email = msg;
                        msg = findpw(id, name, email);
                    }
                    else if (msg.Substring(0, msg.IndexOf("$")).Equals("ALAS"))
                    {
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string airplane_id = msg.Substring(0, msg.IndexOf("$"));
                        msg = msg.Substring(msg.IndexOf("$") + 1);
                        string seat = msg;
                        msg = alarm(id, airplane_id, seat);
                    }
                    

                    byte[] sbuffer = Encoding.Unicode.GetBytes(msg);
                    stream.Write(sbuffer, 0, sbuffer.Length);
                    stream.Flush();

                    if (OnReceived != null)
                    {
                        OnReceived(msg);
                        OnReceived("");
                    }
                }
            }
            catch (SocketException se)
            {
                Trace.WriteLine(string.Format("doChat - SocketException : {0}", se.Message));

                if (clientSocket != null)
                {
                    clientSocket.Close();
                    stream.Close();
                }

                if (OnCalculated != null)
                    OnCalculated();
            }
            catch (Exception ex)
            {
                Trace.WriteLine(string.Format("doChat - Exception : {0}", ex.Message));

                if (clientSocket != null)
                {
                    clientSocket.Close();
                    stream.Close();
                }

                if (OnCalculated != null)
                    OnCalculated();
            }
        }
        /*private void sendMessage()
        {
            try
            {
                Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint E_IP = new IPEndPoint(IPAddress.Parse("210.94.181.219"), 3342);
                server.Connect(E_IP);
                byte[] msg = Encoding.UTF8.GetBytes("This is a test");
                server.Send(msg, SocketFlags.None);

            }
            catch {
                MessageBox.Show("안됨");
            }

        }*/
        private string sendAirplaneList()
        {
            String result = null;
            try
            {

                String strConn = "Server=localhost;Database=airplane;Uid=root;Pwd=gusdh288&;";
                MySqlConnection conn = new MySqlConnection(strConn);
                conn.Open();
                String sql = "select * from airplane";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                MySqlDataReader rd = cmd.ExecuteReader();
                
                while (rd.Read())
                {
                    string id = rd.GetString(0); string region = rd.GetString(1); string country = rd.GetString(2);
                    string d_airport = rd.GetString(3); string a_airport = rd.GetString(4); string date = rd.GetString(5);
                    string time = rd.GetString(6); string cost = rd.GetString(7); string seat_info = rd.GetString(8);
               
                    result += id + " " + region + " " + country + " " + d_airport + " " + a_airport + " " + date + " " + time + " " + cost + " " + seat_info+"$";
                }

                rd.Close();
                conn.Close();
            }
            catch (Exception i)
            {
                Console.WriteLine(i.StackTrace);
            }

                return result+"!";
        }
        
        private string addAccount(string id, string pw, string name, string email, string interest)
        {
            if (!dic_userInfo.ContainsKey(id))
            {
                Account temp = new Account(id, pw, name, email, interest);
                dic_userInfo.Add(temp.id, temp);
                // DB 연결

                MySqlConnection con = new MySqlConnection();
                con.ConnectionString = "Server=localhost;database=airplane;uid=root;pwd=gusdh288&";

                // 삽입 SQL 문
                string strSql = "INSERT INTO account(id, pw, name, email,airplane_id, seat_info, interest) VALUES(@id, @pw, @name, @email, @airplane_id, @seat_info, @interest)";
                MySqlCommand cmd = new MySqlCommand(strSql, con);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@pw", pw);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@airplane_id", "NULL");
                cmd.Parameters.AddWithValue("@seat_info", "NULL");
                cmd.Parameters.AddWithValue("@interest", interest);
 
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                
                return "T";
            }
            else{
                return "F";
            }
        }
        private string modifyAccount(string id, string pw, string name, string email, string interest)
        {
            if (dic_userInfo.ContainsKey(id))
            {
                dic_userInfo[id].pw=pw;
                dic_userInfo[id].name = name;
                dic_userInfo[id].email = email;
                dic_userInfo[id].interest = interest;

                return "T";
            }
            else
            {
                return "F";
            }
        }
        private string login(string id, string pw)
        {
            if (dic_userInfo.ContainsKey(id) && dic_userInfo[id].pw.Equals(pw))
            {
                string alarmService = "";
                if (dic_alarmSeat.ContainsKey(id))
                {
                    alarmService = dic_alarmSeat[id].alarmServiceOkSeat();
                }
                return dic_userInfo[id].ToString() + "$" + alarmService;
            }
            else
            {
                return "F";
            }
        }
        private string findid(string name, string email)
        {
            foreach (KeyValuePair<string, Account> temp in dic_userInfo)
            {
                if (temp.Value.name.Equals(name) && temp.Value.email.Equals(email))
                {
                    return temp.Key;
                }
            }
            return "F";
        }
        private string findpw(string id, string name, string email)
        {
            foreach (KeyValuePair<string, Account> temp in dic_userInfo)
            {
                if (temp.Value.name.Equals(id) && temp.Value.name.Equals(name) && temp.Value.email.Equals(email))
                {
                    return "T";
                }
            }
            return "F";
        }
        private string cancel(string id, string airplane_id, string seat)
        {
            string[] check1={seat,"0"};
            string[] check2={seat,"1"};
            if (dic_userInfo[id].BookedSeats[airplane_id].Contains(seat))
            {
                dic_airplaneList[airplane_id].Seats[seat] = false;
                foreach (KeyValuePair<string, AlarmSeat> temp in dic_alarmSeat)
                {
                    if (temp.Value.containsSeat(seat))
                    {
                        temp.Value.alarmSeats[airplane_id][seat] = "1";
                    }
                }
                return "T";
            }
            else
            {
                return "F";
            }
        }
        private string reserve(string id, string airplane_id, string seat)
        {
            string[] seats = seat.Split(',');
            string falseSeats= "";
            foreach (string temp in seats)
            {
                if (dic_airplaneList[airplane_id].Seats[temp] == true)
                    falseSeats += temp + ",";
            }
            if (falseSeats != "")
                return falseSeats.Substring(0,falseSeats.Length-1);
            foreach (string temp in seats)
            {
                dic_airplaneList[airplane_id].Seats[temp] = true;
                if (!dic_userInfo[id].BookedSeats.ContainsKey(airplane_id))
                {
                    List<string> newlist = new List<string>();
                    dic_userInfo[id].BookedSeats.Add(airplane_id, newlist);
                    dic_userInfo[id].BookedSeats[airplane_id].Add(temp);
                }
                else
                {
                    dic_userInfo[id].BookedSeats[airplane_id].Add(temp);
                }
            }
            return "T";
        }
        private string alarm(string id, string airplane_id, string seat)
        {
            string[] seats = seat.Split(',');
            string falseSeats= "";
            foreach (string temp in seats)
            {
                foreach (KeyValuePair<string, AlarmSeat> alarmtemp in dic_alarmSeat)
                {
                    if (alarmtemp.Value.containsSeat(temp))
                    {
                        falseSeats += temp + ",";
                    }
                }
            }
            if (falseSeats != "")//.Substring(0,falseSeats.Length-1)
                return falseSeats.Substring(0,falseSeats.Length-1);
                if (!dic_alarmSeat.ContainsKey(id))
                {
                    dic_alarmSeat.Add(id, new AlarmSeat(id,airplane_id,seat));
                    return "T";
                }
                else
                {
                    dic_alarmSeat[id].addToAlarmSeats(airplane_id, seat);
                }
            
            return "T";
        }
    }
}
