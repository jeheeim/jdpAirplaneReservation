﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TcpServerExample
{
    class AlarmSeat
    {
        public string id;
        public Dictionary<string,List<string[]>> alarmSeats;
        
        public AlarmSeat(string id, string airplane_id, string seat, string check = "")
        {
            this.id = id;
            alarmSeats = new Dictionary<string, List<string[]>>();
            string[] temp = seat.Split(',');
            addToAlarmSeats(airplane_id, seat, check);
        }
        public void addToAlarmSeats(string airplane_id, string seat, string check = null)
        {
            if (!alarmSeats.ContainsKey(airplane_id))
            {
                List<string[]> newList = new List<string[]>();
                alarmSeats.Add(airplane_id, newList);
            }
            string[] seats = seat.Split(',');
            string[] checks = {"0"};
            if (check != null)
                checks = check.Split(',');
            for(int i = 0; i < seats.Length; i++)
            {
                string[] onePair = new string[2] { seats[i], (check == null)?"0":checks[i] };
                alarmSeats[airplane_id].Add(onePair);
            }
        }
        public bool containsSeat(string seatNum)
        {
            string[] onePair = new string[2] { seatNum, "0" };
            string[] onePair2 = new string[2] { seatNum, "1" };
            foreach (KeyValuePair<string, List<string[]>> target in alarmSeats)
            {
                if (target.Value.Contains(onePair) || target.Value.Contains(onePair2))
                    return false;
            }
            return true;
        }
    }
}
